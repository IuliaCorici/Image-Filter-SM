#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

/* return codes*/
#define STATUS_SUCCES 0
#define ERR_BASE 100
#define ERR_IO (ERR_BASE + 1)
#define ERR_INVALID_ARG_NR (ERR_BASE + 2)
#define ERR_MEMORY (ERR_BASE + 3)
#define ERR_INVALID_FILTER_NAME (ERR_BASE + 4)


/* Filters */
float filters[3][3] = {{0, -2.0 / 3, 0}, {-2.0 / 3, 11.0 / 3, -2.0 / 3}, {0, -2.0 / 3, 0}};

/** Types of pixels **/
/* RGB */
typedef struct
{
	unsigned char red, green, blue;
} rgb_pixel;

/* Gray */
typedef unsigned char gray_pixel;

/** Structure that stores an image, either a grayscale or a rgb one **/
typedef struct
{
	int width, height;
	int type; // 5 - grayscale, 6 - rgb
	unsigned char maxval;
	rgb_pixel *rgb_image;
	gray_pixel *gray_image;
} image;

image img;
image img_co;
int nThreads = 4;
int block_size;

// Read image from file
int read_image(char *img_filename, image *img) {
	FILE *img_file = fopen(img_filename, "r");
	if (img_file == NULL) {
		printf("Cannot open image %s\n", img_filename);
		return ERR_IO;
	}

	char buff_type[3];
	fscanf(img_file, "%s\n%d %d\n%hhd\n", buff_type, &(img->width), &(img->height), &(img->maxval));
	img->type = buff_type[1] - '0';
	int start_image = ftell(img_file);
	fclose(img_file);
	img_file = fopen(img_filename, "rb");
	fseek(img_file, start_image, SEEK_SET);

	if (img->type == 5) {
		img->rgb_image = NULL;
		img->gray_image = (gray_pixel *) malloc(img->height * img->width * sizeof(gray_pixel));
		if (img->gray_image == NULL)
			return ERR_MEMORY;
		fread((img->gray_image), sizeof(gray_pixel) * img->height * img->width, 1, img_file);
	} else {
		img->gray_image = NULL;
		img->rgb_image = (rgb_pixel *) malloc(img->height * img->width * sizeof(rgb_pixel));
		if (img->rgb_image == NULL)
			return ERR_MEMORY;
		fread((img->rgb_image), sizeof(rgb_pixel) * img->height * img->width, 1, img_file);
	}
	fclose(img_file);
	return STATUS_SUCCES;
}

// Write image to file
int write_image(char *img_filename, image *img) {
	FILE *img_file = fopen(img_filename, "wb");
	if (img_file == NULL) {
		printf("Cannot open image %s\n", img_filename);
		return ERR_IO;
	}
	char header[100];
	sprintf(header, "P%d\n%d %d\n%d\n", img->type, img->width, img->height, img->maxval);
	fwrite(header, strlen(header), 1, img_file);

	if (img->type == 5) {
		fwrite((img->gray_image), sizeof(gray_pixel) * img->width * img->height, 1, img_file);
		free(img->gray_image);
		img->gray_image = NULL;
	} else {
		fwrite((img->rgb_image), sizeof(rgb_pixel) * img->width * img->height, 1, img_file);
		free(img->rgb_image);
		img->rgb_image = NULL;
	}

	fclose(img_file);
	return STATUS_SUCCES;
}

// Apply a filter on a grayscale image
void *apply_filter_gray(void *arg)
{
    int id = *(int*)arg;

    int length;
    if (id < nThreads - 1) {
		length = block_size;
	} else {
		length = block_size - (nThreads - ((img.width * img.height) % nThreads)) % nThreads;
	}

	float new_gray_pixel;
	int lin, col;

	for (int i = 0; i < length; i++) {
		lin = (block_size * id + i) / (img.width);
		col = (block_size * id + i) % (img.width);

		if ((lin > 0) && (lin < (img.height - 1)) && (col > 0) && (col < (img.width - 1))) {
			new_gray_pixel = 0;
			for (int i_f = -1; i_f < 2; i_f++)
				for (int j_f = -1; j_f < 2; j_f++) {
					new_gray_pixel += filters[i_f + 1][j_f + 1] * (float)img_co.gray_image[(lin + i_f) * (img.width) + (col + j_f)];
				}

			img.gray_image[lin * (img.width) + col] = (gray_pixel)new_gray_pixel;
		} else {
			img.gray_image[lin * (img.width) + col] = img_co.gray_image[lin * (img.width) + col];
		}
	}
	
}

// Apply a filter on a color image
void *apply_filter_color(void *arg) {

	int id = *(int*)arg;

	float new_pixel_r, new_pixel_g, new_pixel_b;
	int lin, col;

	int length;
    if (id < nThreads - 1) {
		length = block_size;
	} else {
		length = block_size - (nThreads - ((img.width * img.height) % nThreads)) % nThreads;
	}

	for (int i = 0; i < length; i++) {

		lin = (block_size * id + i) / (img.width);
		col = (block_size * id + i) % (img.width);

		if ((lin > 0) && (lin < (img.height - 1)) && (col > 0) && (col < (img.width - 1))) {
			
			new_pixel_r = 0;
			new_pixel_g = 0;
			new_pixel_b = 0;

			for (int i_f = -1; i_f < 2; i_f++) {
				for (int j_f = -1; j_f < 2; j_f++) {
					new_pixel_r += filters[i_f + 1][j_f + 1] * (float)img_co.rgb_image[(lin + i_f) * (img.width) + (col + j_f)].red;
					new_pixel_g += filters[i_f + 1][j_f + 1] * (float)img_co.rgb_image[(lin + i_f) * (img.width) + (col + j_f)].green;
					new_pixel_b += filters[i_f + 1][j_f + 1] * (float)img_co.rgb_image[(lin + i_f) * (img.width) + (col + j_f)].blue;
				}
			}

			img.rgb_image[lin * (img.width) + col].red = (unsigned char)new_pixel_r;
			img.rgb_image[lin * (img.width) + col].green = (unsigned char)new_pixel_g;
			img.rgb_image[lin * (img.width) + col].blue = (unsigned char)new_pixel_b;
		} else {
			img.rgb_image[lin * (img.width) + col].red = img_co.rgb_image[lin * (img.width) + col].red;
			img.rgb_image[lin * (img.width) + col].green = img_co.rgb_image[lin * (img.width) + col].green;
			img.rgb_image[lin * (img.width) + col].blue = img_co.rgb_image[lin * (img.width) + col].blue;
		}
	}

	return STATUS_SUCCES;
}

int main(int argc, char *argv[]) {
	int length;

	if (argc < 3) {
		printf("ERROR: Not enough arguments: <inputFileName> <outputFileName>\n");
		exit(ERR_INVALID_ARG_NR);
	}

	int status_1 = STATUS_SUCCES;
	char img_in_name[100], img_out_name[100];
	strcpy(img_in_name, argv[1]);
	strcpy(img_out_name, argv[2]);
	status_1 = read_image(img_in_name, &img);
	status_1 = read_image(img_in_name, &img_co);

	if (status_1 != STATUS_SUCCES)
		return status_1;

	block_size = (img.width * img.height + (nThreads - ((img.width * img.height) % nThreads)) % nThreads) / nThreads;

    pthread_t threads[nThreads];
    int thread_id[nThreads];
  	int r;
  	long id;
    long arguments[nThreads];
    void *status;

    for (int i = 0; i < nThreads; i++) {
        thread_id[i] = i;
		if (img.type == 5) {
			r = pthread_create(&threads[i], NULL, apply_filter_gray, &thread_id[i]);
		} else {
			r = pthread_create(&threads[i], NULL, apply_filter_color, &thread_id[i]);
		}
  	}
    
    for (int i = 0; i < nThreads; i++) {
		r = pthread_join(threads[i], &status);
  	}


    status_1 = write_image(img_out_name, &img);
    if (status_1 != STATUS_SUCCES)
        return status_1;

	return STATUS_SUCCES;
}